export { default } from "../../layout/Footer";


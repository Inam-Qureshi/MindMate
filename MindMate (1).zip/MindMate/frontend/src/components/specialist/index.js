export { default as CompleteProfile } from './CompleteProfile';
export { default as ApplicationStatus } from './ApplicationStatus';
export { default as PendingApproval } from './PendingApproval';
export { default as ApplicationRejected } from './ApplicationRejected';
export { default as ForumPage } from './ForumPage';
// New modular dashboard
export { default as SpecialistDashboard } from './dashboard';

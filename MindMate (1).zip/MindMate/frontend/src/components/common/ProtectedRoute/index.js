export { default } from './ProtectedRoute';


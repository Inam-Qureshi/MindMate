export { default } from './ErrorBoundary';


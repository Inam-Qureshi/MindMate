export { default as LandingPage } from './LandingPage';
export { default as DevTeam } from './DevTeam';

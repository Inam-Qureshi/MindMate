"""
Adapters for assessment_v2 modules
"""



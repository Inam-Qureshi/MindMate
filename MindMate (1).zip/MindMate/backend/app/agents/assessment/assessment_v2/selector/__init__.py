"""
Module selection components for assessment_v2
"""



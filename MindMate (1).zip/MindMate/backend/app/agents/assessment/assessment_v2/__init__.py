"""
SCID-CV Assessment System V2
Refactored system with minimal questions, intelligent routing, and LLM-based response processing
"""

__version__ = "2.0.0"


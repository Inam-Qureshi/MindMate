"""
Reporting components for assessment_v2
"""



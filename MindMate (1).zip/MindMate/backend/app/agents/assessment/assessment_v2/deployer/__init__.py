"""
Module Deployer for SCID-CV V2
"""

from .module_deployer import SCIDCV2ModuleDeployer

__all__ = [
    "SCIDCV2ModuleDeployer",
]


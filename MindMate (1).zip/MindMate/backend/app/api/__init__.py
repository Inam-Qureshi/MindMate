# app/api/__init__.py

"""
API package for MindMate backend.
"""

__all__ = []


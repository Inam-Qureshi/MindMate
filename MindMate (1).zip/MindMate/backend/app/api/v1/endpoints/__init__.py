# app/api/v1/endpoints/__init__.py

"""
API v1 endpoints package.
"""

__all__ = []

